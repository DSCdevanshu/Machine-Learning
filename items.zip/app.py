import pandas as pd
import xgboost as xgb
from fastapi import FastAPI

app = FastAPI()

test_data = pd.read_pickle('test_data.pkl')
xgb_model = xgb.XGBRegressor()
xgb_model.load_model('xgb_model.json')
features = ['shop_id', 'item_id', 'item_category_id', 'lag_1', 'lag_2', 'lag_3', 'rolling_mean', 'price_trend']

@app.get("/predict/{shop_id}/{item_id}")
async def predict_sales(shop_id: int, item_id: int):
    input_data = test_data[(test_data['shop_id'] == shop_id) & (test_data['item_id'] == item_id)]
    if input_data.empty:
        return {"error": "No data found for the given shop_id and item_id"}
    pred = xgb_model.predict(input_data[features])[0]
    pred = max(pred, 0)
    return {"shop_id": shop_id, "item_id": item_id, "predicted_sales": float(pred)}